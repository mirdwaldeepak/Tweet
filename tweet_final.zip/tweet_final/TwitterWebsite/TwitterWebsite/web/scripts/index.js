$(document).ready(function(){
   $("#tweet").click(function(){
       alert("hello");
   });
});

